# Claude Shutdown Summarizer — what it does & how to use it

Automatically sends `/summarize` to every Cursor integrated terminal running a
`claude` session when you shut down / log out your Mac, shows a popup while it
waits, then lets the shutdown continue once summarizing is done.

## Components

| Piece | Location | Purpose |
|---|---|---|
| Cursor extension | `~/.cursor/extensions/local.claude-shutdown-summarizer-0.0.1/` | Watches for a trigger file, calls `sendText('/summarize')` on every open integrated terminal, waits for new files in each project's `.claude/summaries/`, then writes a "done" marker. |
| Shutdown-catcher app | `~/Applications/ClaudeShutdownSummarizer.app` | A background (no Dock icon) app that intercepts the system quit/shutdown request, shows the popup, touches the trigger file, waits for the "done" marker, then lets shutdown proceed. |
| Trigger/marker files | `~/.claude/shutdown_trigger`, `~/.claude/shutdown_done` | Simple file-based signal between the app and the extension. |
| Debug log | `/tmp/shutdown_summarizer.log` | Step-by-step log of what the shutdown-catcher app did on its last run. |

## One-time setup

1. **Restart Cursor** (⌘Q, then reopen) so it loads the new extension.
2. **Launch the shutdown-catcher app** so it's resident:
   ```
   open ~/Applications/ClaudeShutdownSummarizer.app
   ```
3. (Not done yet — do this once the behavior is verified) **Add it as a Login Item** so it's always running:
   System Settings → General → Login Items → **+** → select `~/Applications/ClaudeShutdownSummarizer.app`.

You only need to do steps 1–3 once. After that, as long as the app is
running (or a login item), it will catch shutdown/log-out automatically.

## How to test

### A. Test the extension alone (no shutdown involved)
With a `claude` session running in a Cursor terminal:
```
touch ~/.claude/shutdown_trigger
```
Within a couple seconds you should see `/summarize` typed into that terminal
automatically. Confirms the extension half works independently.

### B. Test the full flow via Log Out
1. Make sure the app is running (`pgrep -fl ClaudeShutdownSummarizer`).
2. Save any unsaved work — this closes all your apps.
3. In another window, tail the log: `tail -f /tmp/shutdown_summarizer.log`
4. Apple menu → **Log Out** (or ⌘⇧Q).
5. Watch the log:
   - `quit handler entered` → `cleared stale files` → `showed notification` →
     `touched trigger file` → ... → `done file detected at waited=N` (or
     `loop finished`) → `about to continue quit` = **working as intended**.
   - If it stops right after `touched trigger file` and never continues,
     the AppleScript-applet approach isn't getting enough time from a real
     logout either, and we'd need a different (compiled) mechanism — let
     Claude know so it can pivot the implementation.

## Checking if the app is running

It has no Dock icon, menu bar item, or ⌘-Tab entry by design. Check via:
```
pgrep -fl ClaudeShutdownSummarizer
```
or search "applet" / "ClaudeShutdownSummarizer" in Activity Monitor.

## Uninstalling

```
rm -rf ~/Applications/ClaudeShutdownSummarizer.app
rm -rf ~/.cursor/extensions/local.claude-shutdown-summarizer-0.0.1
rm -f ~/.claude/shutdown_trigger ~/.claude/shutdown_done /tmp/shutdown_summarizer.log
```
Also remove it from System Settings → Login Items if you added it there.

## Known limitation

A synthetic `osascript -e 'tell application X to quit'` test showed the app
getting killed almost immediately (after one ~1s tick) instead of running its
full wait loop — this may be specific to how a scripted AppleEvent "quit" is
handled versus a genuine system-initiated logout/shutdown, which is expected
to wait longer. Test B above is the real check; results aren't confirmed yet.
