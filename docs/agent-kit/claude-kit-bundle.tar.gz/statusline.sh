#!/usr/bin/env bash
# Claude Code status line
# Output order: dir | branch | model | context bar
#
# Deploy:
#   cp scripts/statusline.sh ~/.claude/statusline.sh && chmod +x ~/.claude/statusline.sh
#
# settings.json:
#   "statusLine": { "type": "command", "command": "~/.claude/statusline.sh" }

set -euo pipefail

input=$(cat)

# --- Fields from JSON ---
MODEL=$(echo "$input"    | jq -r '.model.display_name // "Agent"')
MODEL_ID=$(echo "$input" | jq -r '.model.id // ""')
DIR=$(echo "$input"      | jq -r '.workspace.current_dir // .cwd // ""')
DIRNAME="${DIR##*/}"
WT=$(echo "$input"       | jq -r '.worktree.name // empty')

# --- Git branch (skip optional locks; silent on non-repo) ---
BRANCH=""
if [ -n "$DIR" ] && command -v git > /dev/null 2>&1; then
  BRANCH=$(git -C "$DIR" -c gc.auto=0 branch --show-current 2>/dev/null || true)
fi

# --- Context %: prefer pre-calculated field; fall back to transcript scan ---
PCT=$(echo "$input" | jq -r '.context_window.used_percentage // empty' | cut -d. -f1)
if [ -z "$PCT" ]; then
  TRANSCRIPT=$(echo "$input" | jq -r '.transcript_path // empty')
  if [ -n "$TRANSCRIPT" ] && [ -f "$TRANSCRIPT" ]; then
    WIN=200000
    [[ "$MODEL_ID" == *"[1m]"* ]] && WIN=1000000   # 1M-context model variant
    TOKENS=$( \
      (grep '"usage"' "$TRANSCRIPT" 2>/dev/null | tail -1 \
        | jq -r '(.message.usage.input_tokens // 0)
                + (.message.usage.cache_read_input_tokens // 0)
                + (.message.usage.cache_creation_input_tokens // 0)') \
      2>/dev/null || echo 0 )
    [[ "$TOKENS" =~ ^[0-9]+$ ]] && [ "$TOKENS" -gt 0 ] \
      && PCT=$((TOKENS * 100 / WIN))
  fi
fi

PCT_NUM=${PCT:-0}
[[ "$PCT_NUM" =~ ^[0-9]+$ ]] || PCT_NUM=0

# --- Progress bar (10 cells) ---
BAR_WIDTH=10
FILLED=$((PCT_NUM * BAR_WIDTH / 100))
EMPTY=$((BAR_WIDTH - FILLED))
BAR=""
[ "$FILLED" -gt 0 ] && printf -v FILL "%${FILLED}s" && BAR="${FILL// /▓}"
[ "$EMPTY"  -gt 0 ] && printf -v PAD  "%${EMPTY}s"  && BAR="${BAR}${PAD// /░}"

# Color by threshold (red >= 80, yellow >= 60, green otherwise)
if   [ "$PCT_NUM" -ge 80 ]; then CTX_COLOR="\033[31m"
elif [ "$PCT_NUM" -ge 60 ]; then CTX_COLOR="\033[33m"
else                              CTX_COLOR="\033[32m"
fi

# --- Render ---
# 1. Directory name (bold white)
[ -n "$DIRNAME" ] && printf "\033[1;37m%s\033[0m" "$DIRNAME"

# 2. Git branch (magenta, in parentheses)
[ -n "$BRANCH" ] && printf "  \033[90m(\033[0m\033[35m%s\033[0m\033[90m)\033[0m" "$BRANCH"

# 3. Worktree label (when present)
[ -n "$WT" ] && printf "  \033[90mwt:%s\033[0m" "$WT"

# 4. Model name (cyan)
printf "  \033[36m%s\033[0m" "$MODEL"

# 5. Context bar + percentage (color-coded)
printf "  ${CTX_COLOR}[%s] %d%%\033[0m" "$BAR" "$PCT_NUM"

printf "\n"
