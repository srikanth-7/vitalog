---
description: Summarize this session, fan out /summarize to every other open Cursor terminal, then shut down the Mac. Running this command IS the confirmation — no extra prompt before shutdown.
---

You are ending this session for the day. The user runs `/shutdown` when they're done working and want every open tab's work captured before the machine powers off — this reuses the existing Cursor extension (`local.claude-shutdown-summarizer-0.0.1`, see `~/.claude/shutdown-summarizer-guide.md`) to fan out to other terminals, but replaces the flaky background app that used to intercept the system shutdown — now the user triggers everything manually with this one command.

## Steps

1. **Pick a slug** for what this session was about: short, kebab-case, descriptive. If the user passed an argument (`$ARGUMENTS`), use that as the slug instead.

2. **Get a timestamp** via `date "+%Y-%m-%d_%H%M"` (file names) and `date "+%Y-%m-%d %H:%M"` (human-readable, inside the file).

3. **Decide where to save the summary:**
   - If the current project has a `.claude/summaries/` directory (or a `/summarize` command at `.claude/commands/summarize.md`), follow that project's own convention — write to `.claude/summaries/<timestamp>_<slug>.md` in the same structure that command already uses.
   - Otherwise, save to `~/.claude/session-summaries/<project-folder-name>/<timestamp>_<slug>.md` (create the directory if needed), using the structure below.

4. **Write the summary** (skip sections that don't apply):

```markdown
# Session summary: <slug>

_Last updated: <timestamp> · branch: <run `git branch --show-current` if in a git repo>_

## Goal
What this session was trying to accomplish (1-2 sentences).

## Status
done / in-progress / blocked — and on what.

## What's been done
- Concrete changes made, each with file path and a one-line reason.

## Current state of the code
- Uncommitted changes (`git status --short`), key files touched, anything half-finished.

## Next steps
- Ordered, specific TODOs to resume. Concrete enough that a fresh session can act without re-deriving context.

## Blockers / open questions
- Anything waiting on the user, backend, or a decision.
```

Keep it tight and high-signal — paste-ready resume context, not a transcript.

5. **Confirm the save** to the user: print the saved path and a one-line recap.

6. **Fan out to every other open terminal.** The Cursor extension watches for a trigger file and, when it appears, types `/summarize` into every open integrated terminal, then waits for a new file to land in each terminal's own `.claude/summaries/` before writing a done marker. Do this now:
   - Clear stale signal files: `rm -f ~/.claude/shutdown_trigger ~/.claude/shutdown_done`
   - Touch the trigger: `touch ~/.claude/shutdown_trigger`
   - Poll for the done file (the extension itself gives up waiting after 60s, so poll a little past that):
     ```
     for i in $(seq 1 70); do [ -f ~/.claude/shutdown_done ] && break; sleep 1; done
     ```
   - If `~/.claude/shutdown_done` appeared, read it (`cat ~/.claude/shutdown_done`) — it's JSON with `terminalCount` and `timedOut`. Tell the user how many terminals were found and flag it if `timedOut` is `true` (means at least one tab didn't finish summarizing in time).
   - If it never appeared after ~70s, tell the user the Cursor extension may not be loaded (Cursor needs to be open with `local.claude-shutdown-summarizer-0.0.1` active) — then proceed to shutdown anyway rather than blocking indefinitely.
   - Clean up: `rm -f ~/.claude/shutdown_trigger ~/.claude/shutdown_done`

   **Do not rely on this step for your own terminal's summary** — you already wrote it directly in steps 1-5. The extension will still type `/summarize` into this terminal too, but since this terminal is busy running `/shutdown` right now, that keystroke just queues up behind the current turn and will never actually run once the machine shuts down. That's expected and harmless — it's not a duplicate because your own summary is already saved.

7. **Shut down the Mac.** Run:
   ```
   osascript -e 'tell application "System Events" to shut down'
   ```
   This triggers the same flow as Apple menu → Shut Down — macOS itself will still prompt to save unsaved documents in other apps and can be cancelled from there, but do not add your own extra confirmation step; the user invoking `/shutdown` already is the confirmation.
   - If it errors with something like "not allowed to send Apple events" or "not authorized", the terminal/Cursor app needs Automation permission for System Events (System Settings → Privacy & Security → Automation). Tell the user this exact fix — don't try `sudo shutdown` as a workaround, it skips the graceful app-save flow.

8. Tell the user shutdown has been initiated, plus the fan-out result from step 6.

## Notes
- This command depends on the Cursor extension `local.claude-shutdown-summarizer-0.0.1` being installed and active (Cursor open) to reach *other* terminals — it reuses that piece of `~/.claude/shutdown-summarizer-guide.md` as-is.
- It replaces `~/Applications/ClaudeShutdownSummarizer.app`, the background app that used to intercept the system shutdown/logout event — that app is no longer needed since this command triggers the same signal files manually and then shuts down itself. Safe to uninstall (steps in the guide) once this command is confirmed working.
- If run outside a git repo or outside any specific project context, still write a best-effort summary of what was discussed/done in the session.
