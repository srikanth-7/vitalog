---
description: Load a saved session summary from .claude/summaries/ and resume that work
---

Resume a parked session from a summary saved by `/summarize`.

## Steps

1. If the user passed a slug (`$ARGUMENTS`), read `.claude/summaries/<slug>.md`.
2. If no argument, list `.claude/summaries/*.md` (run `ls -t .claude/summaries/*.md` so newest is first) and show the user the available summaries with their slug and "last updated" line, then ask which to resume — unless there's only one, in which case load it directly.
3. Read the chosen summary fully, then briefly orient yourself: check `git status --short` and the current branch to see whether the code state still matches what the summary describes. Flag any drift.
4. Give the user a 2-3 line recap (goal + where things stand + the immediate next step) and wait for their go-ahead before acting, unless they already told you to continue.
