---
description: Summarize the current session and save it to .claude/summaries/ so a parked tab can be resumed later
---

You are creating a **resumable summary** of the current session. The user parks tabs (separate Claude sessions) and runs this when a tab has been idle, so they can pick up exactly where they left off later — possibly in a fresh session with no memory of this conversation.

## Steps

1. **Pick a slug** for what this session is about: short, kebab-case, descriptive (e.g. `temp-shift-request-details`, `sentry-triage-graphql`). If the user passed an argument (`$ARGUMENTS`), use that as the slug instead.

2. **Get a timestamp** by running `date "+%Y-%m-%d_%H%M"` via Bash. Use the human-readable form (`date "+%Y-%m-%d %H:%M"`) inside the file.

3. **Write the summary** to a NEW file every time: `.claude/summaries/<timestamp>_<slug>.md`. Never overwrite an existing summary — each `/summarize` run produces its own file (the user prunes old ones manually). Use this structure:

```markdown
# Session summary: <slug>

_Last updated: <timestamp> · branch: <run `git branch --show-current`>_

## Goal
What this tab is trying to accomplish (1-2 sentences).

## Status
done / in-progress / blocked — and on what.

## What's been done
- Concrete changes made, each with the file path and a one-line reason.

## Current state of the code
- Uncommitted changes (`git status --short`), key files touched, anything half-finished.
- Architectural decisions made (GetX bindings, routes, GraphQL queries, API shapes, dev flags).

## Next steps
- Ordered, specific TODOs to resume. Be concrete enough that a fresh session can act without re-deriving context.

## Blockers / open questions
- Anything waiting on the user, the backend, or a decision.

## Manual test / verify steps
- How to confirm the work, if applicable.
```

4. **Keep it tight and high-signal** — this is paste-ready resume context, not a transcript. Prefer file paths and decisions over prose.

5. **Confirm** to the user: print the saved path and a one-line recap. To resume later, they read that file (or run `/resume-summary <slug>` if that command exists).

## Notes
- Capture facts about *this session's work*, not general project knowledge already in CLAUDE.md / docs/ / memory.
- If something significant about how to work was learned (a preference, a gotcha), suggest saving it to memory — but don't write memory automatically from this command.
