---
description: Start a new feature — plan it (feature-planner), map any Figma design (figma-to-flutter), get plan approval, then implement.
---

# /new-feature — orchestrated feature workflow

You are orchestrating a new feature for the HCM Flutter app. Subagents **cannot call other
subagents**, so YOU (main loop) drive this chain. Follow these steps in order.

Feature request (if the user typed one after the command): `$ARGUMENTS`

## Step 1 — Gather intent + Figma
If the feature request is empty or vague, ask what the feature is. Then ask:
> "Is there a Figma design for this? If yes, paste the node URL (or say 'no')."
Wait for the answer before proceeding. Capture the Figma URL/node id if given.

## Step 2 — Plan (feature-planner)
Invoke the `feature-planner` agent with the feature description **and the Figma URL if provided**.
It is read-only and writes a structured plan to `.claude/agent-memory/plans/`. Relay its summary
and the plan file path.

## Step 3 — Map the design (figma-to-flutter) — only if a Figma URL was given
Invoke the `figma-to-flutter` agent in **mapping mode**: tell it to produce the component + token
mapping and proposed widget tree for the node, but **NOT to write any files yet**. It will use
`get_metadata` → catalog lookup → `get_variable_defs`/`get_screenshot`. Collect:
- the `AH-*` → Flutter component mapping,
- the token mapping (colors/typography/spacing),
- any **gaps** (unmapped `AH-*` names, colors with no close token).

## Step 4 — Present the combined plan for approval (PLAN-FIRST GATE)
Synthesize the planner output + the design mapping into ONE plan and present it via
**ExitPlanMode**. The plan must list:
- files to create/edit (exact paths, layered View→ViewModel→Repository→ApiImpl pattern),
- the component + token mapping for each UI section,
- new localization keys needed (`assets/translations/en.json`),
- gaps/assumptions and how you'll resolve them,
- the build order + verification (`flutter analyze`, build_runner if freezed models change).
Do not write any `lib/` files until the user approves.

> Note: `.claude/settings.local.json` currently denies `Write(lib/**)`. If it's still denied at
> approval time, tell the user to remove/scope that deny so the approved writes can land — the
> plan approval is the gate, not the deny rule.

## Step 5 — Implement
After approval, implement the plan. Prefer invoking `figma-to-flutter` (now in write mode) for the
UI/screen files so component + token reuse stays consistent; handle ViewModel/Repository/API wiring
per the plan. Reuse existing components from `.claude/component-catalog.md`; never reinvent.
Register ViewModels in `lib/network/application_bindings.dart`. Keep scope tight — no drive-by
refactors.

## Step 6 — Verify & report
Run `flutter analyze` (and `dart run build_runner build --delete-conflicting-outputs` if freezed
models changed). Report: files changed, components used, tokens used, new string keys, and anything
left for the user (e.g. backend query, manual QA).

## Naming conventions (apply to ALL new code)

Follow standard Dart/Flutter style — the same conventions large teams enforce in review. Lint must
stay green; no new `unused_element`, `non_constant_identifier_names`, or shadowing.

**Casing**
- `lowerCamelCase` — variables, parameters, named args, functions, methods, getters.
- `UpperCamelCase` — classes, enums, extensions, typedefs, mixins.
- `lowerCamelCase` — file-private constants. No `SCREAMING_CASE` in Dart.
- `snake_case.dart` — file names (matches the layered `{feature}_view.dart` pattern).

**Variables & parameters — descriptive, not terse**
- No throwaway single letters (`d`, `s`, `t`, `x`). Name locals after what they hold, typically the
  type in `lowerCamelCase`: `RegularizationModuleData regularization`, `Timings timing`,
  `Splitss session`, `OverTimeModuleData overTime`.
- Loop/lambda vars get a real noun: `.map((Splitss session) => …)`, not `(s) =>`. A bare `e` is only
  acceptable for a trivial one-liner with no meaningful identity.
- Booleans read as a question/state: `is…`, `has…`, `should…`, `can…` (`isKanmo`, `hasModuleData`,
  `canApprove`).
- Collections are plural (`proofsList`, `punchesListDayOne`); a single item is singular.
- Fix typos in identifiers you touch (e.g. `dayNumner` → `dayNumber`).

**Methods & getters**
- Verb-first for actions (`fetchDetails`, `downloadAttachment`, `onApproveBtnClick`); noun/adjective
  for getters (`activeReason`, `headerDate`).
- `_` prefix = library-private. Use it for view helpers and internal viewmodel logic; keep only the
  members the View/other files genuinely call public.
- Event handlers from the UI: `on{Thing}{Action}` (`onApproveBtnClick`, `onRefresh`).

**File structure — group with named extensions (no one giant class)**
Split a screen/viewmodel into intent-named `extension`s in the same file so each concern is isolated
but private helpers stay shareable:
- View: one extension per concern — body, shared sections, a per-type section each
  (`…ArSectionExtension`, `…OdSectionExtension`, …), footer, and a dedicated `…SheetsExtension` for
  all bottom sheets.
- ViewModel: keep only fields + lifecycle (`onInit`) in the class; move the rest into
  `…FunctionsExtension` (getters/helpers), `…Actions` (user-triggered handlers), `…ApiExtension`
  (network), `…PayloadExtension` (payload builders).
- Extension names: `{Feature}{Concern}Extension` in `UpperCamelCase`.

**De-duplicate, don't copy-paste**
When two methods differ only in a value, extract one helper and pass the differing values as
**typed** parameters (`String route`, not `dynamic`). Never widen to `dynamic` to force reuse.

**Use shared constants, not literals**
Don't hardcode a string or number when a constant already covers it:
- Non-translated strings/symbols (e.g. `'*'`, empty string) → `HCMStringConstants`.
- Int literals (page sizes, indices, durations in seconds, etc.) → `IntegerConstants`.
- Dimensions — spacing, padding, radius, icon sizes, opacity fractions → `Numbers`.
- User-facing text is the one exception — that always goes through `tr(LocaleKeys.x)`, not
  `HCMStringConstants`, even if it means adding a new locale key.
Check each constants file for an existing value before adding a new literal or a new constant.
