---
description: Morning Sentry triage — create sentry_fix_<date> from latest bugfix in a worktree, list every mobile-flutter bug + fix, wait for approval, then fix in the background
---

Daily Sentry bug-fix run for project `mobile-flutter`. The user keeps working on their current
branch — **never** checkout/switch/stash in the main repo; everything happens in a worktree.

## 1. Branch + worktree (`release/<latest>` → `bugfix/<latest>` → `sentry_fix_<date>`)

Network commands need `dangerouslyDisableSandbox: true`.

1. `git fetch origin --prune`
2. Latest versions:
   - `git branch -r --list 'origin/release/build*' | sed 's#.*/build##' | sort -V | tail -1`
   - same for `origin/bugfix/build*`
   If they differ, stop and ask which to use.
3. `git merge-base --is-ancestor origin/release/build<v> origin/bugfix/build<v>` — if it fails,
   **stop and report** (bugfix is missing release commits); do not merge.
4. `date=$(date +%Y_%m_%d)`, branch `sentry_fix_$date`, path `../HCM Flutter-sentry_fix_$date`.
   - Worktree already exists → reuse it.
   - Else: `git worktree add "../HCM Flutter-sentry_fix_$date" -b sentry_fix_$date origin/bugfix/build<v>`
     (if the branch exists but no worktree, drop `-b`).
   - `flutter pub get` in the worktree.
5. Tell the user: base `bugfix/build<v>` (contains `release/build<v>`), worktree path.

## 2. Report (read-only)

Spawn the `sentry-fixer` agent (foreground) with: worktree absolute path, **report mode**,
queries `"is:unresolved"` (top 25) and `"is:unresolved age:-24h"`. `$ARGUMENTS`, if given,
narrows the query or lists specific shortIds.

Spot-check a few cited `file:line`s exist before showing them. Show the user the full table and
each proposed diff.

## 3. Approval gate

`AskUserQuestion` (multiSelect) with the **fix**-verdict issues (batch into several questions if
more than 4). **Make no edits before this answer.** If nothing is approved, stop.

## 4. Fix (background)

Spawn `sentry-fixer` with `run_in_background: true`: worktree path, **write mode**, approved
shortIds only. Tell the user they can keep working on their branch.

## 5. When it finishes

- `git -C "<worktree>" diff --stat` and `flutter analyze` on touched files.
- Run the `code-review` skill on the worktree diff.
- Report per issue: files changed, analyze result, review notes.
- **No commit, no push, no Sentry resolve** unless the user asks.
