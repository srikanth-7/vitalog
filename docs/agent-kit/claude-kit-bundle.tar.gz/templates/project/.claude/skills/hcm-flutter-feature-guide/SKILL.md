---
name: hcm-flutter-feature-guide
description: Helps AI understand HCM Flutter architecture, module patterns, API flow, localization, and current feature context.
---

# HCM Flutter Guide

## Architecture
Use existing module structure:
- view/
- business_logic/
- model/
- payload/repository/api_implementation where present

Prefer current patterns over new abstractions.

## State
Use existing GetX/Rx patterns.
Do not replace with Provider/Riverpod/BLoC unless feature already uses it.

## API
Follow repository -> api implementation -> viewmodel flow.
Use existing Dio/GraphQL helpers and interceptors.
Do not bypass token refresh/session headers.

## Localization
Add keys to `assets/translations/en.json`.
Sync all locale files.
Regenerate `locale_keys.g.dart` and `codegen_loader.g.dart`.

## UI
Use existing HCM components, constants, colors, text styles, spacing.
Avoid hardcoded colors/sizes when constants exist.

## New Feature Context
Describe feature here:
- purpose
- screens touched
- API response shape
- edge cases
- expected UI behavior
