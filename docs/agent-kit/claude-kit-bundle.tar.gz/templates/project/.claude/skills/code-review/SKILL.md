---
name: code-review
description: >-
  Review HCM Flutter changes for GetX patterns, routing, localization, API
  flow, and 4.0 UI conventions. Use when reviewing PRs, diffs, or before merge.
---

# HCM Flutter Code Review

Review the changed files against this checklist. Report findings as **Critical / Warning / Suggestion**.

## Architecture

- [ ] New UI in `lib/hcm_4.0/` (not legacy `lib/view/` unless extending existing)
- [ ] Layer order: View → ViewModel → Repository → ApiImplementation
- [ ] ViewModel registered in `lib/network/application_bindings.dart` if new
- [ ] Route in `hcm_route_constants.dart` + `route_manager.dart`

## State & UI

- [ ] GetX patterns (`.obs`, `Obx`, `Get.find`) — no new Provider/Riverpod
- [ ] HCM 4.0 components, colors, spacing constants — no magic numbers
- [ ] Shimmer / loading / empty / error states handled

## API & Security

- [ ] GraphQL uses `moduleSubTaskId` and decrypted responses
- [ ] No bypass of interceptors, token refresh, or AES-GCM encryption
- [ ] `Utils.shared.changeClientUrl()` when switching client context

## Localization

- [ ] Keys in `assets/translations/en.json` only first
- [ ] Sync script run; `locale_keys.g.dart` regenerated if keys added
- [ ] UI strings use `tr(LocaleKeys.*)` not hardcoded English

## Pitfalls

- [ ] Import path `resourses/` spelling preserved
- [ ] No debug JSON (`ddd.json`, `dd.json`) committed
- [ ] No secrets or tokens in code

## Output format

```markdown
## Summary
<one paragraph>

## Critical
- ...

## Warnings
- ...

## Suggestions
- ...

## Verdict
Approve / Request changes
```
